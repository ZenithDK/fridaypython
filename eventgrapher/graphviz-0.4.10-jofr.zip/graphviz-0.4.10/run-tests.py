#!/usr/bin/env python
# run-tests.py

import nose

nose.main()
